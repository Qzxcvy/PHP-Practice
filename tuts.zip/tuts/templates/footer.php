<footer class="section">
    <div class="center grey-text">Copright 2021 Ninja Pizzas</div>
</footer>


</body>