<?php

//ternary operators
//$score = 50;
//echo $score > 40 ? 'high score!' : 'low score :(';

//superglobals
// $_GET['name'], $_POST['name']
echo $_SERVER['SERVER_NAME'].'<br />';
echo $_SERVER['REQUEST METHOD'].'<br />';
echo $_SERVER['SCRIPT_FILENAME'].'<br />';
echo $_SERVER['PHP_SELF'].'<br />'; //USED TO REFER TO SELF
echo $_SERVER['SERVER_NAME'].'<br />';

//$_SESSION


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>